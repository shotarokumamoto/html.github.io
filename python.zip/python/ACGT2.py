S = input()
acgt=["A", "C", "G", "T"]
count = 0
max = 0

for i in S:
    if i in acgt:
        count += 1
        if count > max:
            max = count
    else:
        count = 0

print(max)
