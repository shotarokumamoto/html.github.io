b = input()

if b == "A":
    print("T")
elif b == "T":
    print("A")
elif b == "G":
    print("C")
else:
    print("G")
