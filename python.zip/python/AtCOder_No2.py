N = int(input())
s = input()
print('Yes' if s.count('R')>s.count('B') else 'No')
