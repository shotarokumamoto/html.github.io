n,q = map(int, input().split())
s = "_" + input() + "_"
l, r = 0, n+1

for(t,d) in [input().split() for i in range(q)][::-1]:
    L = d == "L"
    R = d == "R"
    l += (t==s[l+1] and L) - (t==s[l] and R)
    r += (t==s[r] and L) - (t==s[r-1] and R)
print(r-l-1)
