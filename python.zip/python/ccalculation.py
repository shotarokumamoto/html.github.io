# -*- coding: utf-8 -*-

q1 = input("何時に?:")
time = int(q1)
q2 = input("いくつ?:")
num = int(q2)
q3 = input("何円分:
money = int(q3)

def cul(a,b,c):
      if a == 14 and b >= 3:
          return c*0.9
      elif a == 15 and b >= 5:
          return c*0.8
      else:
          return c

fee = int(cul(time,num,money))
print("金額は{}円です".format(fee))
