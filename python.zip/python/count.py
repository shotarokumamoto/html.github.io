N = int(input())
num = list(map(int, input().split()))
count = 0
while not 1 in [i%2 for i in num]:
    num = [i/2 for i in num]
    count += 1
print(count)
