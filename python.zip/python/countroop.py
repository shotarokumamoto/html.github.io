a = int(input())
b = int(input())
c = int(input())
X = int(input())
count = 0
for i in range(a+1):
    for j in range(b+1):
        for k in range(c+1):
             x = 500*i + 100*j + 50*k
             if(x == X):
                 count += 1
print(count)
