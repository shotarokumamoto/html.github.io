#coding: UTF-8

import tkinter.filedialog as fb

path = fb.askopenfilename(title = "処理対象のファイルを指定してください", filetypes = [("HTML",".html")])
print(path)
