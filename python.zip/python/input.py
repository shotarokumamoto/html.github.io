# -*- coding: utf-8 -*-

name=input("お名前は？")
print(name+"さん、こんにちは！")
tall=input("身長は何cmですか?")
tall2 = float(tall)
print("{}cmですね".format(tall2))
