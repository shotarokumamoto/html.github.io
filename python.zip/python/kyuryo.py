# -*- coding: utf-8 -*-
#時給計算プログラム

user1 = input("時給はいくらですか？")
jikyu = int(user1)
user2 = input("何時間働きましたか？")
time = float(user2)
kyuryo = int(jikyu * time)
print("時給{}円で、{}時間勤務".format(user1,user2))
print("給与{}円".format(kyuryo)) 
