process.env.PYTHONIOENCODING = "utf-8";

name = input("あなたの名前は？")
print(str(name))
