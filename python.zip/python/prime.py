def prime(max):
    num = 2
    while (num <= max):
        is_prime = True
        for i in range(2, max):
            if (num % i ) == 0:
                is_prime = False
                break
            if (is_prime):
                yield num
                num += 1

it = prime(50)
for i in it:
    print(i , end =",")
