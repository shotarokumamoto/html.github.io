a = input()
print(a)
