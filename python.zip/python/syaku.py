def syaku_to_cm(syaku):
    return round(syaku * 30.303, 3)
