import syaku;

v = syaku.syaku_to_cm(10)
print("10尺=", v , "cm")
